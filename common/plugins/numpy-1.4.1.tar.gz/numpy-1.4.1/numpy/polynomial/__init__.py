from polynomial import *
from chebyshev import *
from polyutils import *

from numpy.testing import Tester
test = Tester().test
bench = Tester().bench
