
from numpy.oldnumeric.fft import *
import numpy.oldnumeric.fft as nof

__all__ = nof.__all__

del nof
