.. _basics.indexing:

********
Indexing
********

.. seealso:: :ref:`Indexing routines <routines.indexing>`

.. note::

   XXX: Combine ``numpy.doc.indexing`` with material
   section 2.2 Basic indexing?
   Or incorporate the material directly here?


.. automodule:: numpy.doc.indexing
