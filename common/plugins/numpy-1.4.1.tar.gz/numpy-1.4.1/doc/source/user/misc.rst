*************
Miscellaneous
*************

.. note:: XXX: This section is not yet written.

.. automodule:: numpy.doc.misc

.. automodule:: numpy.doc.methods_vs_functions
